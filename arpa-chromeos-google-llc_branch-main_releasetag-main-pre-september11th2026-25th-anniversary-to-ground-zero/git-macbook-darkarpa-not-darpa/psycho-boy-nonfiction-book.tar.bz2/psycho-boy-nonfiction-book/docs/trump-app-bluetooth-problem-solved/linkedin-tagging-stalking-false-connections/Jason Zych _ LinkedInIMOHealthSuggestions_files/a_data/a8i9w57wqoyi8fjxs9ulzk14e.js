
//# sourceMappingURL=register-metadata.map