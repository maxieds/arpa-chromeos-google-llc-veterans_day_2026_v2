// Copyright 2012 The ChromiumOS Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import {lib} from '../../libdot/index.js';

import {newBuffer} from './nassh_buffer.js';
import {Stream} from './nassh_stream.js';

/**
 * Relay ssh-agent messages to another app.
 */
export class SshAgentRelayStream extends Stream {
  constructor() {
    super();

    this.authAgentAppID_ = null;
    this.port_ = null;
    this.pendingMessageSize_ = null;
    this.writeBuffer_ = newBuffer(/* autoack= */ true);
  }

  /**
   * Open a connection to agent.
   *
   * @param {!Object} settings
   * @return {!Promise<void>}
   * @override
   */
  async open(settings) {
    return new Promise((resolve, reject) => {
      this.open_(settings, resolve, reject);
    });
  }

  /**
   * Open a connection to agent.
   *
   * @param {!Object} settings
   * @param {function()} resolve
   * @param {function(?string)} reject
   */
  open_(settings, resolve, reject) {
    this.authAgentAppID_ = settings.authAgentAppID;
    this.port_ = chrome.runtime.connect(this.authAgentAppID_);

    // The other extension (e.g. gnubby) sent us a raw ssh-agent message.
    // Forward it along to the ssh process.
    const normalOnMessage = (msg) => {
      if (msg.data) {
        // The ssh-agent protocol requires a 4-byte length header, so add that
        // to the buffer before sending to the ssh process.
        const size = msg.data.length;
        const buffer = new ArrayBuffer(size + 4);
        const dv = new DataView(buffer);

        // The 4-byte length.
        dv.setUint32(0, size);

        // Append body.
        const body = new Uint8Array(buffer, 4);
        body.set(msg.data);

        // Report to client.
        this.onDataAvailable(buffer);

        // Re-examine write buffer; there might be more data in it.
        setTimeout(this.trySendPacket_.bind(this), 0);
      }
    };

    const normalDisconnect = () => {
      this.port_.onMessage.removeListener(normalOnMessage);
      this.port_.onDisconnect.removeListener(normalDisconnect);
      this.close();
    };

    const initialOnMessage = (msg) => {
      this.port_.onMessage.removeListener(initialOnMessage);
      this.port_.onDisconnect.removeListener(initialDisconnect);
      this.port_.onMessage.addListener(normalOnMessage);
      this.port_.onDisconnect.addListener(normalDisconnect);
      resolve();
    };

    const initialDisconnect = () => {
      this.port_.onMessage.removeListener(initialOnMessage);
      this.port_.onDisconnect.removeListener(initialDisconnect);
      reject(lib.f.lastError());
    };

    this.port_.onMessage.addListener(initialOnMessage);
    this.port_.onDisconnect.addListener(initialDisconnect);
    this.port_.postMessage({'type': 'auth-agent@openssh.com', 'data': [0]});
  }

  /** @override */
  close() {
    if (this.port_) {
      this.port_.disconnect();
    }
    super.close();
  }

  /**
   * Check whether there is enough data in the write buffer to constitute a
   * packet. If so, send packet and handle reply.
   */
  trySendPacket_() {
    // See if we've scanned the message length yet (first 4 bytes).
    if (this.pendingMessageSize_ === null) {
      if (this.writeBuffer_.getUnreadCount() < 4) {
        return;
      }

      // Pull out the 32-bit message length.
      const bytes = this.writeBuffer_.read(4);
      const dv = new DataView(bytes.buffer, bytes.byteOffset);
      this.pendingMessageSize_ = dv.getUint32(0);
    }

    // See if we've got the message body yet.
    if (this.writeBuffer_.getUnreadCount() <
        lib.notNull(this.pendingMessageSize_)) {
      return;
    }

    // Send the body to the extension.
    const data = this.writeBuffer_.read(this.pendingMessageSize_);
    // Restart the message process.
    this.pendingMessageSize_ = null;

    // The postMessage API only accepts JavaScript Arrays, so convert it.
    try {
      this.port_.postMessage({
        'type': 'auth-agent@openssh.com',
        'data': Array.from(data),
      });
    } catch (e) {
      this.close();
    }
  }

  /**
   * Append data to write buffer.
   *
   * @param {!ArrayBuffer} data
   * @override
   */
  async write(data) {
    if (!data.byteLength) {
      return;
    }

    this.writeBuffer_.write(data);

    setTimeout(this.trySendPacket_.bind(this), 0);
  }
}
